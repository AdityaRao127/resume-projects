package musicpack;

public class SQLCommands {
	public static void main(String[]args) {
		
	}
}
